<nav id="sidebar">
    <div class="sidebar-header"> <a href="#" class="sidebarCollapse text-grey" id=""><i class="fas fa-times"></i></a> <a href="index.php"><img src="imgs/logo-cbm.png"></a> </div>
    <ul class="sidenav">
        <li id="dashboard"><a href="index.php"><i class="fas fa-tachometer-alt"></i>Dashboard</a></li>
        <li id="chains"><a href="chains.php"><i class="fas fa-link"></i>Chains</a></li>
        <li id="coops"><a href="coops.php"><i class="fas fa-share-alt"></i>Coops</a></li>
        <li id="licenses"><a href="licenses.php"><i class="fas fa-file"></i>Licenses</a></li>
        <li id="learning-center"><a href="learning-center.php"><i class="fas fa-info-circle"></i>Learning Center</a></li>
        <li id="faq-support"><a href="faq-support.php"><i class="fas fa-question-circle"></i>FAQ & Support</a></li>
    </ul>
</nav>
