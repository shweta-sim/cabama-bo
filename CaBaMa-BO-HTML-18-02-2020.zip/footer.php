<!-- footer start -->
<footer> &copy; 2020 CashBackMatrix. All rights reserved. </footer>
<!-- footer end --> 
